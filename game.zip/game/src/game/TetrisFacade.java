/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;

/**
 *
 * @author Dell
 */
public class TetrisFacade {

    private final TetrisDecorator game;
    JFrame f = new JFrame("Tetris");
    int num = 1;

    public TetrisFacade() {
        game = TetrisDecorator.getInstance();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(12 * 26 + 10, 26 * 23 + 25);
        f.setVisible(true);

        // Keyboard controls
        this.f.addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {
            }

            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:
                        game.rotate(-1);
                        break;
                    case KeyEvent.VK_DOWN:
                        game.rotate(+1);
                        break;
                    case KeyEvent.VK_LEFT:
                        game.move(-1);
                        break;
                    case KeyEvent.VK_RIGHT:
                        game.move(+1);
                        break;
                    case KeyEvent.VK_SPACE:
                        game.dropDown();
                        //game.score += 1;
                        break;
                    case KeyEvent.VK_P:
                        TetrisState s = new PauseState();
                        s.handle(game);
                        num = game.num;
                        
                        break;
                    case KeyEvent.VK_C:
                        TetrisState ss = new ResumeState();
                        ss.handle(game);
                        num = game.num;
                        break;
                }
            }

            public void keyReleased(KeyEvent e) {
            }
        });

        // Make the falling piece drop every second
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(1000);
                        if (num == 1) {
                            game.dropDown();
                        } else {
                            while (num == 0) {
                                Thread.sleep(1000);
                            }
                        }
                    } catch (InterruptedException e) {
                    }
                }
            }
        }.start();
    }

    public void init() {
        TetrisState s = new StartState();
        s.handle(game);
                
        f.add(game);
    }
}
