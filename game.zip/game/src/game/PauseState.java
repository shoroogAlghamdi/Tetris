/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.awt.event.KeyListener;

/**
 *
 * @author layan
 */
public class PauseState extends TetrisState {

    @Override
    public void handle(TetrisDecorator t) {
      t.setDrop(0);
      t.setState(this);
    }

}
